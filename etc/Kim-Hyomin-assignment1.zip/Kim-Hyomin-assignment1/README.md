Programming Assignment 1: Hyomin Kim, HYOMKIM
sys, socket libraries are used.
Below is the test example.
Part 1: python webserver.py -> enter address: localhost/HelloWorld.html
Part 2: python proxyserver.py 127.0.0.1 -> enter address: 127.0.0.1:8888/www.wikipedia.org
I tested for my html, google.com, wikipedia.org, and the websites given in the assignment pdf.